package com.work.portal.model;

public class UserInfo {

}
