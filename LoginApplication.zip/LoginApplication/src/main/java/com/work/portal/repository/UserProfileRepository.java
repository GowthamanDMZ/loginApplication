package com.work.portal.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.work.portal.model.UserProfile;


public interface UserProfileRepository extends MongoRepository<UserProfile, Integer>{
	

}
